from setuptools import find_packages, setup

package_name = 'turtlesim_snake'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/snake.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='aa',
    maintainer_email='aa@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'leader_controller = turtlesim_snake.leader_controller:main',
            'follower_controller = turtlesim_snake.follower_controller:main',
            'spawn_turtles = turtlesim_snake.spawn_turtle:main',
            
        ],
    },
)
