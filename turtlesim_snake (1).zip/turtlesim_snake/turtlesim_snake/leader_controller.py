import math

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose


class LeaderController(Node):

    def __init__(self):
        super().__init__('leader_controller')

        self.publisher_ = self.create_publisher(
            Twist,
            '/turtle1/cmd_vel',
            10
        )

        self.pose_subscriber = self.create_subscription(
            Pose,
            '/turtle1/pose',
            self.pose_callback,
            10
        )

        self.pose = None
        self.timer = self.create_timer(0.1, self.move_snake)

        self.linear_speed = 2.0
        self.angular_speed = 1.0
        self.counter = 0

    def pose_callback(self, msg):
        self.pose = msg

    def _normalize_angle(self, angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    def _wall_escape_heading(self, pose):
        boundary = 1.0
        headings = []

        if pose.x < boundary:
            headings.append(0.0)
        elif pose.x > 11.0 - boundary:
            headings.append(math.pi)

        if pose.y < boundary:
            headings.append(math.pi / 2.0)
        elif pose.y > 11.0 - boundary:
            headings.append(-math.pi / 2.0)

        if not headings:
            return None

        return min(
            headings,
            key=lambda heading: abs(self._normalize_angle(heading - pose.theta))
        )

    def should_turn(self):
        if self.pose is None:
            return False

        boundary = 1.0
        heading_x = math.cos(self.pose.theta)
        heading_y = math.sin(self.pose.theta)

        if self.pose.x < boundary and heading_x < 0:
            return True
        if self.pose.x > 11.0 - boundary and heading_x > 0:
            return True
        if self.pose.y < boundary and heading_y < 0:
            return True
        if self.pose.y > 11.0 - boundary and heading_y > 0:
            return True

        return False

    def _wall_avoidance_twist(self):
        msg = Twist()
        msg.linear.x = 0.0

        desired_heading = self._wall_escape_heading(self.pose)
        if desired_heading is None:
            msg.angular.z = self.angular_speed
            return msg

        angle_error = self._normalize_angle(desired_heading - self.pose.theta)
        msg.angular.z = self.angular_speed * math.copysign(1.0, angle_error)
        return msg

    def move_snake(self):
        if self.pose is None:
            return

        if self.should_turn():
            msg = self._wall_avoidance_twist()
        else:
            msg = Twist()
            msg.linear.x = self.linear_speed

            # Make the turtle periodically turn
            if self.counter % 50 < 25:
                msg.angular.z = self.angular_speed
            else:
                msg.angular.z = -self.angular_speed

        self.publisher_.publish(msg)
        self.counter += 1


def main(args=None):
    rclpy.init(args=args)

    node = LeaderController()

    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
