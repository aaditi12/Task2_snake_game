import math

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist
from turtlesim.msg import Pose


class FollowerController(Node):

    def __init__(self):
        super().__init__('follower_controller')

        self.declare_parameter('target_turtle', 'turtle1')
        self.declare_parameter('follower_turtle', 'turtle2')

        self.target_name = self.get_parameter(
            'target_turtle'
        ).value

        self.follower_name = self.get_parameter(
            'follower_turtle'
        ).value

        self.target_pose = None
        self.follower_pose = None

        self.target_subscriber = self.create_subscription(
            Pose,
            f'/{self.target_name}/pose',
            self.target_pose_callback,
            10
        )

        self.follower_subscriber = self.create_subscription(
            Pose,
            f'/{self.follower_name}/pose',
            self.follower_pose_callback,
            10
        )

        self.velocity_publisher = self.create_publisher(
            Twist,
            f'/{self.follower_name}/cmd_vel',
            10
        )

        self.timer = self.create_timer(0.1, self.follow_target)

    def target_pose_callback(self, msg):
        self.target_pose = msg

    def follower_pose_callback(self, msg):
        self.follower_pose = msg

    def _normalize_angle(self, angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    def _wall_escape_heading(self, pose):
        boundary = 1.0
        headings = []

        if pose.x < boundary:
            headings.append(0.0)
        elif pose.x > 11.0 - boundary:
            headings.append(math.pi)

        if pose.y < boundary:
            headings.append(math.pi / 2.0)
        elif pose.y > 11.0 - boundary:
            headings.append(-math.pi / 2.0)

        if not headings:
            return None

        return min(
            headings,
            key=lambda heading: abs(self._normalize_angle(heading - pose.theta))
        )

    def is_blocked(self):
        if self.follower_pose is None:
            return False

        boundary = 1.0
        heading_x = math.cos(self.follower_pose.theta)
        heading_y = math.sin(self.follower_pose.theta)

        if self.follower_pose.x < boundary and heading_x < 0:
            return True
        if self.follower_pose.x > 11.0 - boundary and heading_x > 0:
            return True
        if self.follower_pose.y < boundary and heading_y < 0:
            return True
        if self.follower_pose.y > 11.0 - boundary and heading_y > 0:
            return True

        return False

    def _wall_avoidance_twist(self):
        msg = Twist()
        msg.linear.x = 0.0

        desired_heading = self._wall_escape_heading(self.follower_pose)
        if desired_heading is None:
            msg.angular.z = 2.0
            return msg

        angle_error = self._normalize_angle(desired_heading - self.follower_pose.theta)
        msg.angular.z = 2.0 * math.copysign(1.0, angle_error)
        return msg

    def follow_target(self):

        if self.target_pose is None or self.follower_pose is None:
            return

        if self.is_blocked():
            msg = self._wall_avoidance_twist()
            self.velocity_publisher.publish(msg)
            return

        msg = Twist()
        dx = self.target_pose.x - self.follower_pose.x
        dy = self.target_pose.y - self.follower_pose.y

        distance = math.sqrt(dx * dx + dy * dy)

        angle_to_target = math.atan2(dy, dx)

        angle_error = self._normalize_angle(angle_to_target - self.follower_pose.theta)

        msg.linear.x = 1.5 * distance
        msg.angular.z = 4.0 * angle_error

        self.velocity_publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)

    node = FollowerController()

    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
