import math
import random

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_srvs.srv import Empty
from turtlesim.msg import Pose
from turtlesim.srv import Kill, SetPen, Spawn


class SnakeGameNode(Node):

    def __init__(self):
        super().__init__('snake_game')

        self.spawn_client = self.create_client(Spawn, 'spawn')
        self.kill_client = self.create_client(Kill, 'kill')
        self.clear_client = self.create_client(Empty, 'clear')

        if not self.spawn_client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error('Spawn service is not available.')
            rclpy.shutdown()
            return

        if not self.kill_client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error('Kill service is not available.')
            rclpy.shutdown()
            return

        if not self.clear_client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error('Clear service is not available.')
            rclpy.shutdown()
            return

        self.leader_name = 'turtle1'
        self.food_name = 'rabbit'
        self.body_names = []
        self.next_body_id = 2

        self.turtle_poses = {}
        self.cmd_publishers = {}
        self.pen_clients = {}
        self.food_pose = None
        self.food_spawn_in_progress = False
        self.body_spawn_in_progress = False

        self._clear_screen()
        self._setup_turtle(self.leader_name)

        self.timer = self.create_timer(0.05, self.control_loop)
        self.spawn_food()

    def _clear_screen(self):
        request = Empty.Request()
        self.clear_client.call_async(request)

    def _setup_turtle(self, name):
        if name in self.cmd_publishers:
            return

        self.turtle_poses[name] = None
        self.cmd_publishers[name] = self.create_publisher(
            Twist,
            f'/{name}/cmd_vel',
            10,
        )
        self.create_subscription(
            Pose,
            f'/{name}/pose',
            lambda msg, turtle_name=name: self._pose_callback(msg, turtle_name),
            10,
        )
        self.pen_clients[name] = self.create_client(SetPen, f'/{name}/set_pen')
        self._set_turtle_pen(name, r=0, g=0, b=0, width=0, off=1)

    def _pose_callback(self, msg, name):
        self.turtle_poses[name] = msg
        if name == self.food_name:
            self.food_pose = msg

    def _set_turtle_pen(self, name, r=0, g=0, b=0, width=0, off=1):
        client = self.pen_clients.get(name)
        if client is None:
            client = self.create_client(SetPen, f'/{name}/set_pen')
            self.pen_clients[name] = client

        if not client.wait_for_service(timeout_sec=5.0):
            self.get_logger().warning(f'SetPen service unavailable for {name}')
            return

        request = SetPen.Request()
        request.r = r
        request.g = g
        request.b = b
        request.width = width
        request.off = off
        client.call_async(request)

    def spawn_food(self):
        if self.food_spawn_in_progress:
            return

        self.get_logger().info('Spawning rabbit at a random position')
        request = Spawn.Request()
        request.x = random.uniform(1.5, 9.5)
        request.y = random.uniform(1.5, 9.5)
        request.theta = random.uniform(-math.pi, math.pi)
        request.name = self.food_name

        self.food_spawn_in_progress = True
        self.food_pose = None

        future = self.spawn_client.call_async(request)
        future.add_done_callback(self._on_food_spawned)

    def _on_food_spawned(self, future):
        self.food_spawn_in_progress = False
        try:
            response = future.result()
            self.get_logger().info(f"Spawned rabbit '{response.name}'")
            self._setup_turtle(response.name)
            self._set_turtle_pen(response.name, off=1)
        except Exception as exc:
            self.get_logger().error(f'Failed to spawn food turtle: {exc}')
            self.food_name = None

    def control_loop(self):
        leader_pose = self.turtle_poses.get(self.leader_name)
        if leader_pose is None or self.food_name is None or self.food_pose is None:
            return

        if self._distance(self.leader_name, self.food_name) < 0.45:
            self._eat_food()
            return

        leader_twist = self._compute_twist_to_target(
            self.leader_name,
            self.food_name,
            max_speed=2.0,
        )
        if self._needs_wall_avoidance(self.leader_name):
            leader_twist = self._wall_avoidance_twist(self.leader_name)
        self.cmd_publishers[self.leader_name].publish(leader_twist)

        previous_name = self.leader_name
        for body_name in self.body_names:
            if self.turtle_poses.get(body_name) is None or self.turtle_poses.get(previous_name) is None:
                previous_name = body_name
                continue

            twist = self._compute_twist_to_target(body_name, previous_name, max_speed=1.2)
            if self._needs_wall_avoidance(body_name):
                twist = self._wall_avoidance_twist(body_name)
            self.cmd_publishers[body_name].publish(twist)
            previous_name = body_name

    def _eat_food(self):
        self.get_logger().info('Turtle1 ate the rabbit. Growing the snake.')
        self._kill_food()
        self._spawn_body_segment()

    def _kill_food(self):
        if self.food_name is None:
            return

        request = Kill.Request()
        request.name = self.food_name
        future = self.kill_client.call_async(request)
        future.add_done_callback(self._on_food_killed)

    def _on_food_killed(self, future):
        try:
            future.result()
            self.get_logger().info('Rabbit removed.')
        except Exception as exc:
            self.get_logger().error(f'Failed to remove rabbit: {exc}')

        self.food_pose = None
        self.food_spawn_in_progress = False
        self.spawn_food()

    def _spawn_body_segment(self):
        if self.body_spawn_in_progress:
            return

        body_name = f'turtle{self.next_body_id}'
        follower_pose = self.turtle_poses.get(self.body_names[-1] if self.body_names else self.leader_name)
        if follower_pose is None:
            follower_pose = self.turtle_poses[self.leader_name]

        x = follower_pose.x - math.cos(follower_pose.theta) * 0.6
        y = follower_pose.y - math.sin(follower_pose.theta) * 0.6
        theta = follower_pose.theta

        request = Spawn.Request()
        request.x = max(1.5, min(9.5, x))
        request.y = max(1.5, min(9.5, y))
        request.theta = theta
        request.name = body_name

        self.body_spawn_in_progress = True
        future = self.spawn_client.call_async(request)
        future.add_done_callback(lambda future, name=body_name: self._on_body_spawned(future, name))

    def _on_body_spawned(self, future, body_name):
        self.body_spawn_in_progress = False
        try:
            response = future.result()
            self.get_logger().info(f"Spawned snake body turtle '{response.name}'")
            self._setup_turtle(body_name)
            self._set_turtle_pen(body_name, off=1)
            self.body_names.append(body_name)
            self.next_body_id += 1
        except Exception as exc:
            self.get_logger().error(f'Failed to spawn snake body turtle: {exc}')

    def _compute_twist_to_target(self, follower_name, target_name, max_speed=1.5):
        follower_pose = self.turtle_poses[follower_name]
        target_pose = self.turtle_poses[target_name]

        dx = target_pose.x - follower_pose.x
        dy = target_pose.y - follower_pose.y
        distance = math.hypot(dx, dy)
        angle_to_target = math.atan2(dy, dx)
        angle_error = self._normalize_angle(angle_to_target - follower_pose.theta)

        twist = Twist()
        twist.linear.x = max(0.2, min(max_speed, 1.2 * distance))
        twist.angular.z = 4.0 * angle_error

        if distance < 0.7:
            twist.linear.x = min(twist.linear.x, 0.8)

        return twist

    def _distance(self, name_a, name_b):
        pose_a = self.turtle_poses[name_a]
        pose_b = self.turtle_poses[name_b]
        return math.hypot(pose_a.x - pose_b.x, pose_a.y - pose_b.y)

    def _normalize_angle(self, angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    def _needs_wall_avoidance(self, name):
        pose = self.turtle_poses.get(name)
        if pose is None:
            return False

        boundary = 1.0
        heading_x = math.cos(pose.theta)
        heading_y = math.sin(pose.theta)

        return (
            (pose.x < boundary and heading_x < 0) or
            (pose.x > 11.0 - boundary and heading_x > 0) or
            (pose.y < boundary and heading_y < 0) or
            (pose.y > 11.0 - boundary and heading_y > 0)
        )

    def _wall_avoidance_twist(self, name):
        pose = self.turtle_poses.get(name)
        if pose is None:
            return Twist()

        desired_heading = self._wall_escape_heading(pose)
        twist = Twist()
        twist.linear.x = 0.3

        if desired_heading is None:
            twist.angular.z = 1.0
            return twist

        angle_error = self._normalize_angle(desired_heading - pose.theta)
        twist.angular.z = 2.0 * math.copysign(1.0, angle_error)
        return twist

    def _wall_escape_heading(self, pose):
        boundary = 1.0
        headings = []

        if pose.x < boundary:
            headings.append(0.0)
        elif pose.x > 11.0 - boundary:
            headings.append(math.pi)

        if pose.y < boundary:
            headings.append(math.pi / 2.0)
        elif pose.y > 11.0 - boundary:
            headings.append(-math.pi / 2.0)

        if not headings:
            return None

        return min(
            headings,
            key=lambda heading: abs(self._normalize_angle(heading - pose.theta))
        )


def main(args=None):
    rclpy.init(args=args)
    node = SnakeGameNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
